-- Adminer 3.6.1 MySQL dump

SET NAMES utf8;
SET foreign_key_checks = 0;
SET time_zone = 'SYSTEM';
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `client`;
CREATE TABLE `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_project` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `job_title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '0',
  `user` int(11) NOT NULL DEFAULT '0',
  `date_created` int(11) NOT NULL,
  `date_updated` int(11) NOT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `client` (`id`, `id_project`, `name`, `email`, `phone`, `company`, `job_title`, `image`, `active`, `user`, `date_created`, `date_updated`, `deleted`) VALUES
(1,	1,	'Sander den Heijer',	'sander.denheijer@autotrack.nl',	'',	'Autotrack',	'Product Owner (Main point of contact)',	'',	1,	0,	0,	0,	0),
(2,	1,	'Willem Barentz',	'willem.barentz@autotrack.nl',	'',	'Autotrack',	'Design Responsible',	'',	1,	0,	0,	0,	0);

DROP TABLE IF EXISTS `mobgenner`;
CREATE TABLE `mobgenner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `skype` varchar(255) NOT NULL,
  `job_title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '0',
  `user` int(11) NOT NULL DEFAULT '0',
  `date_created` int(11) NOT NULL,
  `date_updated` int(11) NOT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `mobgenner` (`id`, `name`, `email`, `phone`, `skype`, `job_title`, `image`, `active`, `user`, `date_created`, `date_updated`, `deleted`) VALUES
(1,	'David Souto',	'david.souto@mobgen.com',	'',	'david.souto.mobgen',	'Web and Backend Run & Maintain',	'1807717722555b54bde3e38_david.png',	1,	1,	0,	1432048829,	0),
(2,	'Verónica Portas',	'veronica.portas@mobgen.com',	'',	'',	'Project Manager',	'',	1,	0,	0,	0,	0),
(3,	'Nestor Garcia',	'nestor.garcia@mobgen.com',	'',	'',	'iOS Developer',	'',	0,	0,	0,	0,	0);

DROP TABLE IF EXISTS `new_field`;
CREATE TABLE `new_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `label` varchar(255) NOT NULL,
  `type_field` int(11) NOT NULL,
  `table` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `date_created` int(11) NOT NULL,
  `date_updated` int(11) NOT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `new_field` (`id`, `name`, `label`, `type_field`, `table`, `position`, `date_created`, `date_updated`, `deleted`) VALUES
(1,	'ads',	'Ads',	2,	'project',	1,	0,	0,	0),
(2,	'test',	'Test',	1,	'type',	1,	0,	0,	0),
(3,	'test_field',	'Test Field',	2,	'project',	2,	0,	0,	0),
(4,	'test_scripts',	'Test scripts',	5,	'project',	1,	0,	0,	0),
(5,	'roadmap',	'Roadmap',	5,	'project',	2,	0,	0,	0),
(6,	'casa',	'Casa',	2,	'client',	0,	0,	0,	0);

DROP TABLE IF EXISTS `new_field_project`;
CREATE TABLE `new_field_project` (
  `new_field_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  PRIMARY KEY (`new_field_id`,`project_id`),
  KEY `element_id` (`new_field_id`),
  KEY `new_field_project_ibfk_2` (`project_id`),
  CONSTRAINT `new_field_project_ibfk_1` FOREIGN KEY (`new_field_id`) REFERENCES `new_field` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `new_field_project_ibfk_2` FOREIGN KEY (`project_id`) REFERENCES `project` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `new_field_project` (`new_field_id`, `project_id`) VALUES
(1,	1),
(3,	1),
(3,	3),
(4,	4),
(5,	4),
(6,	3);

DROP TABLE IF EXISTS `new_field_values`;
CREATE TABLE `new_field_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `new_field` int(11) NOT NULL,
  `view_id` int(11) NOT NULL,
  `value` varchar(255) NOT NULL,
  `date_created` int(11) NOT NULL,
  `date_updated` int(11) NOT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `new_field` (`new_field`),
  CONSTRAINT `new_field_values_ibfk_1` FOREIGN KEY (`new_field`) REFERENCES `new_field` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `new_field_values` (`id`, `new_field`, `view_id`, `value`, `date_created`, `date_updated`, `deleted`) VALUES
(2,	1,	3,	'casa',	0,	0,	0),
(3,	1,	1,	'Yes only for NL',	0,	0,	0),
(4,	1,	1,	'Yes only for NL',	0,	0,	0),
(5,	3,	1,	'Texto de autortrack en el campo de prueba',	0,	0,	0),
(6,	3,	3,	'Texto de prueba en el projecto de pruebas',	0,	0,	0);

DROP TABLE IF EXISTS `project`;
CREATE TABLE `project` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `active` int(11) NOT NULL DEFAULT '0',
  `internal` int(11) NOT NULL DEFAULT '0',
  `additional_information` varchar(255) NOT NULL,
  `onboarding_document` varchar(255) NOT NULL,
  `date_created` int(11) NOT NULL,
  `date_updated` int(11) NOT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `project` (`id`, `name`, `alias`, `logo`, `description`, `active`, `internal`, `additional_information`, `onboarding_document`, `date_created`, `date_updated`, `deleted`) VALUES
(1,	'AutoTrack',	'The car website',	'11856653185549f78970c5f_footer-app_notifier-icon-nl-512.png',	'Search used cars for NL and BE. Save favorites, searches...',	1,	0,	'<p style=\"font-family: HelveticaNeue-Light;\">smb://192.168.5.20/Mobgen/Accounts/Autotrack</p>',	'<p style=\"font-family: HelveticaNeue-Light;\">https://docs.google.com/a/mobgen.com/document/d/1na9gv-4KlMKdBxHbF_WZKIJpnFO9rUc2zkA8AWu1Wek/edit?usp=sharing</p>',	0,	1431607778,	0),
(3,	'Test',	'test',	'',	'test',	0,	1,	'',	'',	1431082533,	1431607794,	0),
(4,	'ABN AMRO - PBI',	'PBI',	'162216388555b59f907c1b_abn_amro.jpeg',	'Private Banking customers secure access to view the latest news from the bank, real-time stock exchange data, video reports and a variety of research documents.',	1,	0,	'<p style=\"font-family: HelveticaNeue-Light;\">\\\\MGS001\\Mobgen\\Accounts\\ABN AMRO\\ABN AMRO - Stella</p>',	'<p style=\"font-family: HelveticaNeue-Light;\">https://docs.google.com/a/mobgen.com/document/d/1zapH7g9eh1fCpAK3R</p>',	1432050169,	1432135123,	0);

DROP TABLE IF EXISTS `project_type`;
CREATE TABLE `project_type` (
  `project_id` int(11) NOT NULL,
  `type_id` int(255) NOT NULL,
  KEY `project_id` (`project_id`),
  KEY `type_id` (`type_id`),
  CONSTRAINT `project_type_ibfk_3` FOREIGN KEY (`project_id`) REFERENCES `project` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `project_type_ibfk_5` FOREIGN KEY (`type_id`) REFERENCES `type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `project_type` (`project_id`, `type_id`) VALUES
(1,	5),
(1,	6),
(1,	3),
(1,	2),
(1,	7),
(3,	4),
(4,	6),
(4,	9);

DROP TABLE IF EXISTS `system`;
CREATE TABLE `system` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `min_app_version` varchar(7) DEFAULT NULL,
  `build_url` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `system` (`id`, `last_update`, `min_app_version`, `build_url`) VALUES
(1,	'2012-10-08 08:09:57',	'0.2',	NULL);

DROP TABLE IF EXISTS `type`;
CREATE TABLE `type` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `date_created` int(11) NOT NULL,
  `date_updated` int(11) NOT NULL,
  `deleted` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `type` (`id`, `name`, `description`, `logo`, `date_created`, `date_updated`, `deleted`) VALUES
(2,	'iOS Phone',	'This is a description',	'39400937355488d75468a7_iphone.png',	1430220242,	1431943947,	0),
(3,	'iOS iPad',	'',	'91359940155488e500e62e_ipad.png',	1430221675,	1430818384,	0),
(4,	'Responsive Web',	'',	'7917382515549e449219b8_responsive_web2.png',	1430292879,	1430905929,	0),
(5,	'android Phone',	'',	'105054999455488e600be1f_android_mobile.png',	1430316876,	1430818400,	0),
(6,	'android Tablet',	'',	'1677844295549e1a50bfca_android_tablet.png',	1430838589,	1430905253,	0),
(7,	'Web Mobile',	'Only web mobile',	'8945395985549e5e6e90fc_webmobile.png',	1430838614,	1430906342,	0),
(8,	'Apple watch',	'',	'14117785575549e125db590_apple-watch2.png',	1430900915,	1430905125,	0),
(9,	'CMS',	'CMS without Frontend',	'1108026473555b5731c299e_Screenshot_2015-05-19_17.30.23.png',	1432049457,	1432049457,	0);

DROP TABLE IF EXISTS `webuser`;
CREATE TABLE `webuser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `password` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `role` int(11) DEFAULT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '1',
  `last_login` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `webuser` (`id`, `username`, `password`, `role`, `active`, `last_login`) VALUES
(1,	'admin',	'$2a$08$ws01ErL.2X8HA376FnEUE.rsplVw5RxME9Cfnv7MPgAGV5HZ.mQNi',	9,	1,	'2015-05-22T16:13:45+0200'),
(2,	'dev',	'$2a$08$TU1zOBypeFKRcpD/VZ9EJuMjtNP44upL8PF7T7emSN4vCn9bL8TOy',	3,	1,	'2015-05-18T12:11:10+0200'),
(3,	'projects',	'$2a$08$gT7et9wP3vDrUAG1KpsBIOXtiGhimINOXPgg8.TOJaANh/K.RO2UK',	1,	1,	'2015-05-18T12:12:18+0200'),
(4,	'client',	'$2a$08$FuJ4SFouNp1asvSQLPe22e.u0HIsFiu2vWk0WoQkRFu1wqvmIXVly',	2,	1,	'2015-05-18T12:11:51+0200'),
(5,	'test',	'$2a$08$GbSa/20jGKHdpuXKhUg2SuF2Kj0lhlFLHrK01HbyP3qBMqAMqElrS',	1,	1,	'2015-05-19T10:15:36+0200'),
(6,	'david.souto@mobgen.com',	'$2a$08$Yxl03abLwXrRq6kbAY.XlO0234oZwYmkGIN1oz2Pf10W5RQtH1o2K',	9,	1,	'2015-05-19T13:54:31+0200');

DROP TABLE IF EXISTS `webuser_project`;
CREATE TABLE `webuser_project` (
  `webuser_id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  PRIMARY KEY (`webuser_id`,`project_id`),
  KEY `element_id` (`webuser_id`),
  KEY `user_project_ibfk_2` (`project_id`),
  CONSTRAINT `user_project_ibfk_1` FOREIGN KEY (`webuser_id`) REFERENCES `webuser` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_project_ibfk_2` FOREIGN KEY (`project_id`) REFERENCES `project` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- 2015-05-25 17:29:55
